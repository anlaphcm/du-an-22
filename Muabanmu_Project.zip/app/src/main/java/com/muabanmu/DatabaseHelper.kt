package com.muabanmu

import android.content.*
import android.database.sqlite.*
import android.database.Cursor

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "muabanmu.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE transactions(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                name TEXT,
                kg REAL,
                price REAL,
                doMu REAL,
                total REAL,
                edited INTEGER
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(t: TransactionModel) {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put("date", t.date)
        cv.put("name", t.name)
        cv.put("kg", t.kg)
        cv.put("price", t.price)
        cv.put("doMu", t.doMu)
        cv.put("total", t.total)
        cv.put("edited", t.edited)
        db.insert("transactions", null, cv)
    }
}

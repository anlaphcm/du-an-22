package com.muabanmu

data class TransactionModel(
    var id: Int = 0,
    var date: String,
    var name: String,
    var kg: Double,
    var price: Double,
    var doMu: Double,
    var total: Double,
    var edited: Int = 0
)

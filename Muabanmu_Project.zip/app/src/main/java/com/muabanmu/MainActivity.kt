package com.muabanmu

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import android.database.Cursor

class MainActivity : AppCompatActivity() {

    lateinit var db: DatabaseHelper
    lateinit var listView: ListView
    lateinit var totalText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)
        listView = findViewById(R.id.listView)
        totalText = findViewById(R.id.totalText)

        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            startActivity(Intent(this, AddEditActivity::class.java))
        }

        loadData()
    }

    private fun loadData() {
        val cursor: Cursor = db.readableDatabase.rawQuery("SELECT * FROM transactions ORDER BY id DESC", null)
        val list = ArrayList<String>()
        var sum = 0.0

        while (cursor.moveToNext()) {
            val date = cursor.getString(1)
            val name = cursor.getString(2)
            val kg = cursor.getDouble(3)
            val price = cursor.getDouble(4)
            val doMu = cursor.getDouble(5)
            val total = cursor.getDouble(6)
            sum += total
            list.add("$date - $name - $kg kg x $price x $doMu = $total")
        }

        totalText.text = "Tổng: $sum"
        listView.adapter = ArrayAdapter(this,
            android.R.layout.simple_list_item_1, list)
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }
}

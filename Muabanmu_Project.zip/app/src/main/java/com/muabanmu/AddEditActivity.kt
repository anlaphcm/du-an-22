package com.muabanmu

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.*

class AddEditActivity : AppCompatActivity() {

    lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        db = DatabaseHelper(this)

        val edtDate = findViewById<EditText>(R.id.edtDate)
        val edtName = findViewById<EditText>(R.id.edtName)
        val edtKg = findViewById<EditText>(R.id.edtKg)
        val edtPrice = findViewById<EditText>(R.id.edtPrice)
        val edtDo = findViewById<EditText>(R.id.edtDo)

        findViewById<Button>(R.id.btnSave).setOnClickListener {

            val kg = edtKg.text.toString().toDouble()
            val price = edtPrice.text.toString().toDouble()
            val doMu = edtDo.text.toString().toDouble()
            val total = kg * price * doMu

            val t = TransactionModel(
                date = edtDate.text.toString(),
                name = edtName.text.toString(),
                kg = kg,
                price = price,
                doMu = doMu,
                total = total
            )

            db.insert(t)
            finish()
        }
    }
}
